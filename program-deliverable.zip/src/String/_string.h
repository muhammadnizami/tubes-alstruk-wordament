#ifndef _string_h
#define _string_h

#include "../ADT Boolean/boolean.h"

boolean _strcmp(char * a, char * b);
//mengembalikan true bila a dan b berbeda

char * _strcpy(char * dest, char * src);

char * _strcat(char * dest, char * src);

#endif
