#ifndef game_h
#define game_h
#include "ADT Priority Queue/priority_queue.h"
#include "ADT Queue/queuelist.h"

void PlayGame(int board, Queue * Sug, PriorityQueue * Disp, int * score);

#endif
