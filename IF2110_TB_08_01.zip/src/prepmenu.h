#ifndef prepmenu_h
#define prepmenu_h

#include "mainmenu.h"
void prepmenu(adrUser P);
#endif
